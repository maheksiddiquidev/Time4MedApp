package com.example.time4medapp

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    private lateinit var editName: EditText
    private lateinit var editEmail: EditText
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        editName = findViewById(R.id.edit_name)
        editEmail = findViewById(R.id.edit_email)
        btnSave = findViewById(R.id.btn_save_profile)

        loadProfile()

        btnSave.setOnClickListener {
            saveProfile()
            ToastUtils.showCustomToast(this, "Profile Saved Successfully!")
            finish()
        }
    }

    private fun saveProfile() {
        val name = editName.text.toString()
        val email = editEmail.text.toString()

        val sharedPreferences = getSharedPreferences("UserProfile", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        editor.putString("name", name)
        editor.putString("email", email)
        editor.apply()
    }

    private fun loadProfile() {
        val sharedPreferences = getSharedPreferences("UserProfile", Context.MODE_PRIVATE)

        val savedName = sharedPreferences.getString("name", "")
        val savedEmail = sharedPreferences.getString("email", "")

        editName.setText(savedName)
        editEmail.setText(savedEmail)
    }

    private fun showCustomToast(message: String) {
        val inflater: LayoutInflater = layoutInflater
        val layout = inflater.inflate(R.layout.custom_toast, null)

        val text = layout.findViewById<TextView>(R.id.toast_text)
        text.text = message

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT
        toast.view = layout
        toast.show()
    }
}