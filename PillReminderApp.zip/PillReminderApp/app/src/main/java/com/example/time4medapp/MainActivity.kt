package com.example.time4medapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import androidx.core.view.GravityCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)
        val menuButton = findViewById<ImageButton>(R.id.btn_menu)
        val navigationView = findViewById<NavigationView>(R.id.navigation_view)

        // 🔹 Open Drawer when hamburger clicked
        menuButton.setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        // 🔹 Load Drawer Header Data
        val headerView = navigationView.getHeaderView(0)
        val headerName = headerView.findViewById<TextView>(R.id.header_user_name)
        val headerEmail = headerView.findViewById<TextView>(R.id.header_user_email)

        val sharedPreferences = getSharedPreferences("UserProfile", Context.MODE_PRIVATE)
        val savedName = sharedPreferences.getString("name", "User Name")
        val savedEmail = sharedPreferences.getString("email", "user@email.com")

        headerName.text = savedName
        headerEmail.text = savedEmail

        // 🔹 Handle Drawer Menu Clicks
        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {

                R.id.nav_profile -> {
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    drawerLayout.closeDrawer(GravityCompat.START)
                    true
                }

                R.id.nav_settings -> {
                    drawerLayout.closeDrawer(GravityCompat.START)
                    true
                }

                else -> false
            }
        }

        val fabAddMedication = findViewById<FloatingActionButton>(R.id.fab_add_medication)
        fabAddMedication.setOnClickListener {
            val intent = Intent(this, AddMedicationActivity::class.java)
            startActivity(intent)
        }

        // ✅ NEW AI FLOATING BUTTON
        val fabAiChat = findViewById<FloatingActionButton>(R.id.fab_ai_chat)
        fabAiChat.setOnClickListener {
            val intent = Intent(this, AIChatActivity::class.java)
            startActivity(intent)
        }

        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    true
                }
                R.id.navigation_history -> {
                    val intent = Intent(this, HistoryActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
    }

    override fun onResume() {
        super.onResume()

        val navigationView = findViewById<NavigationView>(R.id.navigation_view)
        val headerView = navigationView.getHeaderView(0)
        val headerName = headerView.findViewById<TextView>(R.id.header_user_name)
        val headerEmail = headerView.findViewById<TextView>(R.id.header_user_email)

        val sharedPreferences = getSharedPreferences("UserProfile", Context.MODE_PRIVATE)
        val savedName = sharedPreferences.getString("name", "User Name")
        val savedEmail = sharedPreferences.getString("email", "user@email.com")

        headerName.text = savedName
        headerEmail.text = savedEmail

        val tvWelcome = findViewById<TextView>(R.id.text_welcome)
        tvWelcome.text = "Welcome $savedName! Tap the + button to add medication."
    }

    override fun onBackPressed() {
        val drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}